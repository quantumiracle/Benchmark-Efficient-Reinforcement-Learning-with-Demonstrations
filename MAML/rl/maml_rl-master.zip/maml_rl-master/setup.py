# setup.py
from setuptools import setup

setup(
    name='rllab',
    version='0.1.0',
    packages=['rllab'],
)
